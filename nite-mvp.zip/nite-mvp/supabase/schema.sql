-- NITE MVP database schema for Supabase (Postgres).
-- Run in Supabase SQL Editor only after creating a new project.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 2 and 24),
  age smallint not null check (age >= 18 and age <= 99),
  bio text not null default '' check (char_length(bio) <= 160),
  photo_path text,
  interests text[] not null default '{}',
  is_visible boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.clubs (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  created_at timestamptz not null default now()
);

create table if not exists public.club_events (
  id uuid primary key default gen_random_uuid(),
  club_id uuid not null references public.clubs(id) on delete cascade,
  name text not null,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  is_active boolean not null default false,
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);

create table if not exists public.event_attendance (
  event_id uuid not null references public.club_events(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  is_visible boolean not null default true,
  primary key (event_id, user_id)
);

create table if not exists public.likes (
  from_user uuid not null references public.profiles(id) on delete cascade,
  to_user uuid not null references public.profiles(id) on delete cascade,
  event_id uuid not null references public.club_events(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (from_user, to_user, event_id),
  check (from_user <> to_user)
);

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.club_events(id) on delete cascade,
  user_a uuid not null references public.profiles(id) on delete cascade,
  user_b uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  check (user_a <> user_b),
  unique(event_id, user_a, user_b)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);

create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  reported_id uuid not null references public.profiles(id) on delete cascade,
  reason text not null check (char_length(reason) between 3 and 500),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.clubs enable row level security;
alter table public.club_events enable row level security;
alter table public.event_attendance enable row level security;
alter table public.likes enable row level security;
alter table public.matches enable row level security;
alter table public.messages enable row level security;
alter table public.blocks enable row level security;
alter table public.reports enable row level security;

-- A user can read/update their own profile. Public profile discovery should be exposed
-- via a carefully scoped server/RPC query that checks active event attendance, visibility,
-- blocks and age eligibility; do not grant unrestricted profile reads to anon/authenticated.
create policy "profiles_select_own" on public.profiles for select to authenticated using (id = auth.uid());
create policy "profiles_insert_own" on public.profiles for insert to authenticated with check (id = auth.uid() and age >= 18);
create policy "profiles_update_own" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid() and age >= 18);

create policy "clubs_read_authenticated" on public.clubs for select to authenticated using (true);
create policy "events_read_authenticated" on public.club_events for select to authenticated using (true);
create policy "attendance_read_self" on public.event_attendance for select to authenticated using (user_id = auth.uid());
create policy "attendance_join_self" on public.event_attendance for insert to authenticated with check (user_id = auth.uid());
create policy "attendance_update_self" on public.event_attendance for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "likes_read_participant" on public.likes for select to authenticated using (from_user = auth.uid() or to_user = auth.uid());
create policy "likes_insert_self" on public.likes for insert to authenticated with check (from_user = auth.uid());
create policy "likes_delete_self" on public.likes for delete to authenticated using (from_user = auth.uid());

create policy "matches_read_participant" on public.matches for select to authenticated using (user_a = auth.uid() or user_b = auth.uid());
create policy "messages_read_match_participant" on public.messages for select to authenticated using (exists (select 1 from public.matches m where m.id = match_id and (m.user_a = auth.uid() or m.user_b = auth.uid())));
create policy "messages_insert_match_participant" on public.messages for insert to authenticated with check (sender_id = auth.uid() and exists (select 1 from public.matches m where m.id = match_id and (m.user_a = auth.uid() or m.user_b = auth.uid())));

create policy "blocks_read_self" on public.blocks for select to authenticated using (blocker_id = auth.uid());
create policy "blocks_insert_self" on public.blocks for insert to authenticated with check (blocker_id = auth.uid());
create policy "blocks_delete_self" on public.blocks for delete to authenticated using (blocker_id = auth.uid());
create policy "reports_insert_self" on public.reports for insert to authenticated with check (reporter_id = auth.uid());
create policy "reports_read_self" on public.reports for select to authenticated using (reporter_id = auth.uid());

-- Storage bucket setup: create a private bucket named `profile-photos` in the dashboard.
-- Add policies for authenticated users so paths begin with auth.uid(); avoid public buckets
-- for profile images if users expect their profiles to be hidden outside active club events.
