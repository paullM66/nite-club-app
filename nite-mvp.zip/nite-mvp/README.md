# NITE — Club social discovery MVP

Mobile-first React + TypeScript + Vite prototype for discovering people at the same club, mutual likes, and chat.

## What's implemented

- Dark, mobile-first UI and 18+ age confirmation screen.
- Discover screen with sample profiles, likes, pass, and a demo mutual match.
- Matches list and local chat UI with quick prompts.
- Profile editor, local photo upload, interests, and visibility toggle.
- Club/event join dialog; QR-style share-link preview using `?club=...&event=...`.
- Local persistence in `localStorage` for fast product validation.
- Supabase client/config scaffold and a starter Postgres schema with RLS policies.

## Run locally

Requires Node.js 20+.

```bash
npm install
npm run dev
```

Vite prints a local URL, normally `http://localhost:5173`.

## Demo mode vs production

By default, the app is a **single-browser demo**. Profile edits, likes, matches, and messages are stored in that browser only. Sample profiles are demonstration data; they are not real users. QR is a share-link preview, not a secure proof of entry. Do not deploy this as a live dating service without backend integration.

## Connect Supabase

1. Create a Supabase project.
2. Copy `.env.example` to `.env.local` and add the project URL and anon key.
3. Run `supabase/schema.sql` in the Supabase SQL editor.
4. Configure Auth providers and a private `profile-photos` storage bucket.
5. Implement and test the production data layer before setting `is_visible` profiles live. In particular, discovery must be scoped to active event attendance and visibility, and likes/matches should be created transactionally server-side.

The current UI only detects whether Supabase config exists; it does not yet read/write real Supabase users. That integration is the next implementation milestone.

## Suggested architecture

- `src/App.tsx` — prototype screens and interactions
- `src/styles.css` — responsive visual system
- `src/supabase.ts` — Supabase client configuration
- `supabase/schema.sql` — initial database schema and row-level security policies

## Before public launch

- Real email/phone sign-in, email verification, account deletion, and session management.
- Secure event QR tokens generated and validated server-side; do not rely on query parameters for access control.
- Backend-enforced 18+ age gate, rate limiting, anti-spam, reporting/blocking, moderation and support workflow.
- Mutual-match transaction/RPC and strict chat authorization.
- Private image storage with access rules, image size/type validation, and EXIF metadata removal.
- Privacy notice, terms, retention/deletion policy, GDPR review, and incident response.
- Accessibility, device testing, backups, and production error monitoring.
