import { useEffect, useMemo, useRef, useState } from 'react'
import { Heart, MessageCircle, UserRound, QrCode, Sparkles, MapPin, ChevronRight, X, Check, ArrowLeft, Send, Camera, ShieldCheck, Users, Music2, Settings, LogOut, Plus, ScanLine, CircleHelp, ExternalLink } from 'lucide-react'
import { hasSupabaseConfig } from './supabase'
import { QRCodeSVG } from 'qrcode.react'

type Person = { id: string; name: string; age: number; bio: string; photo: string; interests: string[]; club: string; online?: boolean }
type ChatMessage = { id: string; from: string; text: string; time: string }
type Chat = { personId: string; messages: ChatMessage[] }
type UserProfile = { name: string; age: number; bio: string; photo: string; interests: string[]; visible: boolean }

const initialPeople: Person[] = [
  { id:'p1', name:'Ema', age:23, bio:'Tancuju, dokud nezhasnou světla ✨', photo:'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=900&auto=format&fit=crop&q=85', interests:['House','Cocktails','Cestování'], club:'Moon Club', online:true },
  { id:'p2', name:'Tereza', age:22, bio:'Tady kvůli hudbě. Možná i kvůli tobě.', photo:'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=900&auto=format&fit=crop&q=85', interests:['Techno','Móda','Sushi'], club:'Moon Club', online:true },
  { id:'p3', name:'Niki', age:24, bio:'První drink je na rozjezd, druhý na příběhy.', photo:'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=900&auto=format&fit=crop&q=85', interests:['R&B','Brunch','Festivaly'], club:'Moon Club' },
  { id:'p4', name:'Klára', age:21, bio:'Doporuč mi song a možná máš vyhráno.', photo:'https://images.unsplash.com/photo-1508217957608-1b0d3f7b0f74?w=900&auto=format&fit=crop&q=85', interests:['Pop','Káva','Filmy'], club:'Moon Club', online:true },
  { id:'p5', name:'Sofie', age:25, bio:'Dobrá hudba, špatná rozhodnutí? Jen ta první.', photo:'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=900&auto=format&fit=crop&q=85', interests:['Disco','Umění','Víno'], club:'Moon Club' },
]
const seedMatches: string[] = []
const getStored = <T,>(key:string, fallback:T):T => { try { const raw=localStorage.getItem(key); return raw ? JSON.parse(raw) as T : fallback } catch { return fallback } }
const save = (key:string, value:unknown) => { try { localStorage.setItem(key, JSON.stringify(value)) } catch { /* storage can be full after uploading large images */ } }
const timeNow = () => new Date().toLocaleTimeString('cs-CZ',{hour:'2-digit',minute:'2-digit'})

export default function App() {
  const params = new URLSearchParams(window.location.search)
  const [activeTab,setActiveTab] = useState<'discover'|'matches'|'profile'>('discover')
  const [people,setPeople] = useState<Person[]>(initialPeople)
  const [profile,setProfile] = useState<UserProfile>(()=>getStored('nite-profile',{name:'Alex',age:24,bio:'Jsem tu pro dobrou hudbu a nové tváře.',photo:'',interests:['House','Noční život'],visible:true}))
  const [liked,setLiked] = useState<string[]>(()=>getStored('nite-liked',[]))
  const [matches,setMatches] = useState<string[]>(()=>getStored('nite-matches',seedMatches))
  const [chats,setChats] = useState<Chat[]>(()=>getStored('nite-chats',[]))
  const [current,setCurrent] = useState(0)
  const [selectedChat,setSelectedChat] = useState<string|null>(null)
  const [message,setMessage] = useState('')
  const [showJoin,setShowJoin] = useState(false)
  const [showProfileEdit,setShowProfileEdit] = useState(false)
  const [showQR,setShowQR] = useState(false)
  const [toast,setToast] = useState('')
  const [club,setClub] = useState(()=>params.get('club') || localStorage.getItem('nite-club') || 'Moon Club')
  const [eventCode,setEventCode] = useState(()=>params.get('event') || localStorage.getItem('nite-event') || 'SAT-1010')
  const [ageConfirmed,setAgeConfirmed] = useState(()=>getStored('nite-age-confirmed',false))
  const [registered,setRegistered] = useState(()=>getStored('nite-registered',false))
  const [signupName,setSignupName] = useState('')
  const [signupAge,setSignupAge] = useState('18')
  const [signupEmail,setSignupEmail] = useState('')
  const [signupPassword,setSignupPassword] = useState('')
  const [signupError,setSignupError] = useState('')
  const fileInput = useRef<HTMLInputElement>(null)

  useEffect(()=>{save('nite-profile',profile)},[profile])
  useEffect(()=>{save('nite-liked',liked)},[liked])
  useEffect(()=>{save('nite-matches',matches)},[matches])
  useEffect(()=>{save('nite-chats',chats)},[chats])
  useEffect(()=>{localStorage.setItem('nite-club',club);localStorage.setItem('nite-event',eventCode)},[club,eventCode])
  useEffect(()=>{if(toast){const id=window.setTimeout(()=>setToast(''),2600);return()=>window.clearTimeout(id)}},[toast])

  const visiblePeople = useMemo(()=>people.filter(p=>p.id!== 'me' && !matches.includes(p.id) && p.club===club),[people,matches,club])
  const person = visiblePeople[current % Math.max(visiblePeople.length,1)]
  const matchedPeople = people.filter(p=>matches.includes(p.id))
  const activeChat = chats.find(c=>c.personId===selectedChat)
  const selectedPerson = people.find(p=>p.id===selectedChat)

  const likePerson = (p:Person) => {
    if(liked.includes(p.id)){setToast('Už jsi tomuto profilu dal/a like.');return}
    setLiked(prev=>[...prev,p.id])
    // Demo seed: p2 has liked the current user, so the first like demonstrates a mutual match.
    if(p.id==='p2' || seedMatches.includes(p.id)){
      setMatches(prev=>prev.includes(p.id)?prev:[...prev,p.id])
      setChats(prev=>prev.some(c=>c.personId===p.id)?prev:[...prev,{personId:p.id,messages:[{id:crypto.randomUUID(),from:p.id,text:'Ahoj! Tak jsme se našli ✨',time:timeNow()}]}])
      setToast(`Je to shoda s ${p.name}! 💜`)
    } else setToast(`Like odeslán pro ${p.name}`)
    setCurrent(n=>n+1)
  }
  const passPerson = () => setCurrent(n=>n+1)
  const sendMessage = () => {
    if(!message.trim() || !selectedChat) return
    const newMsg:ChatMessage={id:crypto.randomUUID(),from:'me',text:message.trim(),time:timeNow()}
    setChats(prev=>prev.some(c=>c.personId===selectedChat)?prev.map(c=>c.personId===selectedChat?{...c,messages:[...c.messages,newMsg]}:[...c]):[...prev,{personId:selectedChat,messages:[newMsg]}])
    setMessage('')
  }
  const joinClub = () => {
    if(!club.trim() || !eventCode.trim()){setToast('Vyplň název klubu a kód večera.');return}
    setClub(club.trim());setEventCode(eventCode.trim().toUpperCase());setShowJoin(false);setCurrent(0);setToast(`Jsi připojen/a: ${club.trim()} 🎉`)
  }
  const uploadPhoto = (file?:File) => {
    if(!file)return
    if(!file.type.startsWith('image/')){setToast('Vyber prosím obrázek.');return}
    if(file.size>4*1024*1024){setToast('Pro demo vyber fotku do 4 MB.');return}
    const reader=new FileReader();reader.onload=()=>setProfile(p=>({...p,photo:String(reader.result)}));reader.readAsDataURL(file)
  }
  const qrUrl = `${window.location.origin}${window.location.pathname}?club=${encodeURIComponent(club)}&event=${encodeURIComponent(eventCode)}`

  if(!ageConfirmed) return <div className="age-gate"><div className="age-logo">N<span>•</span>TE</div><div className="age-card"><div className="eyebrow"><Sparkles size={14}/> NOC JE MLADÁ</div><h1>Večer, na který<br/><em>nezapomeneš.</em></h1><p>NITE propojuje lidi, kteří jsou právě teď ve stejném klubu. Poznej někoho nového, ještě než dohraje další track.</p><div className="age-note"><ShieldCheck size={18}/><span>Pro osoby starší 18 let. Tvoje fotka a profil jsou viditelné jen při zapnuté viditelnosti.</span></div><button className="primary wide" onClick={()=>{setAgeConfirmed(true);save('nite-age-confirmed',true)}}>Je mi 18 nebo více <ChevronRight size={18}/></button><div className="subtle tiny center">Pokračováním potvrzuješ, že splňuješ věkovou hranici.</div></div><div className="age-footer">POTKEJ SE JINAK · NITE 2026</div></div>

  if(ageConfirmed && !registered) return <div className="age-gate signup-gate"><div className="age-logo">N<span>•</span>TE</div><form className="signup-card" onSubmit={e=>{e.preventDefault();const age=Number(signupAge);if(signupName.trim().length<2){setSignupError('Zadej přezdívku alespoň se 2 znaky.');return}if(age<18||age>99){setSignupError('NITE je jen pro osoby od 18 let.');return}if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(signupEmail)){setSignupError('Zkontroluj e-mailovou adresu.');return}if(signupPassword.length<8){setSignupError('Heslo musí mít alespoň 8 znaků.');return}setProfile(p=>({...p,name:signupName.trim(),age,visible:true}));save('nite-demo-email',signupEmail.trim());save('nite-registered',true);setRegistered(true);setSignupPassword('');setSignupError('')}}><div className="eyebrow"><Sparkles size={14}/> ZAČNI SVŮJ VEČER</div><h1>Vytvoř si<br/><em>svůj profil.</em></h1><p>Za pár vteřin jsi součástí večera. V demo verzi se účet ukládá pouze do tohoto prohlížeče.</p><label>Jméno nebo přezdívka<input required minLength={2} maxLength={24} value={signupName} onChange={e=>setSignupName(e.target.value)} placeholder="Jak ti máme říkat?" autoComplete="nickname"/></label><label>Věk<input required type="number" min={18} max={99} value={signupAge} onChange={e=>setSignupAge(e.target.value)}/></label><label>E-mail<input required type="email" value={signupEmail} onChange={e=>setSignupEmail(e.target.value)} placeholder="ty@email.cz" autoComplete="email"/></label><label>Heslo<input required type="password" minLength={8} value={signupPassword} onChange={e=>setSignupPassword(e.target.value)} placeholder="Alespoň 8 znaků" autoComplete="new-password"/></label>{signupError&&<div className="form-error">{signupError}</div>}<button className="primary wide" type="submit">Vytvořit demo účet <ChevronRight size={18}/></button><div className="subtle tiny center">Demo registrace neověřuje e-mail a nevytváří skutečný online účet.</div></form><div className="age-footer">POTKEJ SE JINAK · NITE 2026</div></div>

  return <div className="app-shell">
    <header className="topbar"><button className="wordmark" onClick={()=>{setActiveTab('discover');setSelectedChat(null)}}>N<span>•</span>TE</button><button className="club-pill" onClick={()=>setShowJoin(true)}><span className="live-dot"/><span className="club-label">{club}</span><ChevronRight size={14}/></button><button className="icon-button top-action" aria-label="QR kód" onClick={()=>setShowQR(true)}><QrCode size={20}/></button></header>
    <main className="main-content">
      {selectedChat && selectedPerson ? <section className="chat-view"><div className="chat-header"><button className="back-button" onClick={()=>setSelectedChat(null)}><ArrowLeft size={20}/></button><img src={selectedPerson.photo} className="avatar"/><div className="chat-heading"><strong>{selectedPerson.name}</strong><span><span className="live-dot small"/> Shoda z dnešního večera</span></div><button className="icon-button" onClick={()=>setToast('Bezpečnostní funkce bude v další verzi.')}><CircleHelp size={19}/></button></div><div className="chat-safety"><ShieldCheck size={15}/> Potkávej se na veřejném místě a respektuj hranice.</div><div className="messages">{(activeChat?.messages||[]).map(m=><div key={m.id} className={`message-row ${m.from==='me'?'mine':''}`}><div className="bubble">{m.text}<span>{m.time}</span></div></div>)}</div><div className="quick-prompts">{['Kde tě najdu? 📍','Dáme drink? 🍸','Jaký je tvůj song? 🎶'].map(q=><button key={q} onClick={()=>setMessage(q)}>{q}</button>)}</div><form className="composer" onSubmit={e=>{e.preventDefault();sendMessage()}}><input value={message} onChange={e=>setMessage(e.target.value)} placeholder="Napiš zprávu…" aria-label="Zpráva"/><button className="send-button" aria-label="Odeslat zprávu" type="submit"><Send size={18}/></button></form></section>
      : activeTab==='discover' ? <section className="discover-view"><div className="section-head"><div><div className="eyebrow"><span className="live-dot"/> DNES VEČER</div><h1>Možná tu je<br/><em>někdo tvůj.</em></h1></div><div className="count-bubble"><Users size={15}/><span>{people.length+7} <small>lidí</small></span></div></div><div className="event-line"><MapPin size={15}/><span>{club}</span><span className="dot-sep">·</span><Music2 size={15}/><span>Večírek právě probíhá</span></div>
        {person ? <div className="profile-card"><div className="card-image-wrap"><img className="person-photo" src={person.photo} alt={`Profil ${person.name}`} onError={e=>{(e.currentTarget as HTMLImageElement).src='https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=900&auto=format&fit=crop&q=85'}}/><div className="photo-shade"/><div className="photo-topline"><span className="tag"><Sparkles size={12}/> V TOMHLE KLUBU</span>{person.online&&<span className="online-tag"><span className="live-dot"/> online</span>}</div><div className="person-info"><div className="person-title"><h2>{person.name}, {person.age}</h2><span className="verified"><Check size={13}/></span></div><p>{person.bio}</p><div className="interest-list">{person.interests.map(i=><span key={i}>{i}</span>)}</div></div></div><div className="card-actions"><button className="pass-action" aria-label="Přeskočit profil" onClick={passPerson}><X size={25}/></button><div className="action-caption">PŘESKOČIT</div><button className="like-action" aria-label="Dát like" onClick={()=>likePerson(person)}><Heart size={25} fill="currentColor"/></button><div className="action-caption">LÍBÍ SE MI</div></div></div>:<div className="empty-card"><Sparkles size={32}/><h2>To je pro teď všechno.</h2><p>Zkus to za chvíli znovu nebo se podívej na své shody.</p><button className="secondary" onClick={()=>{setCurrent(0);setPeople(initialPeople)}}>Obnovit profily</button></div>}
        <div className="privacy-line"><ShieldCheck size={15}/><span>Tvůj profil vidí jen lidé, kteří jsou součástí tohoto večera.</span></div>
      </section> : activeTab==='matches' ? <section className="matches-view"><div className="eyebrow">TA CHEMIE JE VZÁJEMNÁ</div><h1>Tvoje <em>shody.</em></h1><p className="section-copy">Když přeskočí jiskra, začíná to tady.</p>{matchedPeople.length ? <div className="matches-grid">{matchedPeople.map(p=><button className="match-card" key={p.id} onClick={()=>setSelectedChat(p.id)}><div className="match-photo-wrap"><img src={p.photo} alt={p.name}/><span className="match-heart"><Heart size={13} fill="currentColor"/></span></div><strong>{p.name}, {p.age}</strong><span>{chats.find(c=>c.personId===p.id)?.messages.slice(-1)[0]?.text||'Máte shodu! Napiš první.'}</span><div className="open-chat">Otevřít chat <ChevronRight size={14}/></div></button>)}</div>:<div className="empty-card compact"><Heart size={30}/><h2>Zatím žádné shody</h2><p>Dej někomu like. Pokud se líbíte navzájem, najdeš ho tady.</p><button className="primary" onClick={()=>setActiveTab('discover')}>Objevovat lidi</button></div>}</section> : <section className="my-profile-view"><div className="eyebrow">TVŮJ VEČER, TVOJE PRAVIDLA</div><h1>Tvůj <em>profil.</em></h1><div className="my-profile-card"><div className="my-profile-photo">{profile.photo?<img src={profile.photo} alt="Tvoje profilová fotka"/>:<div className="photo-placeholder"><Camera size={30}/><span>Přidej fotku</span></div>}<button onClick={()=>fileInput.current?.click()} className="edit-photo"><Camera size={17}/></button><input ref={fileInput} type="file" accept="image/*" hidden onChange={e=>uploadPhoto(e.target.files?.[0])}/></div><div className="my-profile-details"><h2>{profile.name}, {profile.age}</h2><p>{profile.bio||'Doplň krátké bio a dej ostatním důvod tě oslovit.'}</p><div className="interest-list dark">{profile.interests.map(i=><span key={i}>{i}</span>)}</div></div><button className="edit-profile-button" onClick={()=>setShowProfileEdit(true)}>Upravit profil <ChevronRight size={17}/></button></div><div className="settings-list"><button className="setting-row" onClick={()=>setProfile(p=>({...p,visible:!p.visible}))}><span className="setting-icon"><Users size={18}/></span><span className="setting-copy"><strong>Viditelnost profilu</strong><small>{profile.visible?'Ostatní tě v klubu mohou objevit':'Tvůj profil je skrytý'}</small></span><span className={`toggle ${profile.visible?'on':''}`}><span/></span></button><button className="setting-row" onClick={()=>setShowQR(true)}><span className="setting-icon"><QrCode size={18}/></span><span className="setting-copy"><strong>Vstup do klubu</strong><small>{club} · {eventCode}</small></span><ChevronRight size={18}/></button><button className="setting-row" onClick={()=>setToast('Blokování a nahlášení přidáme před ostrým spuštěním.')}><span className="setting-icon"><ShieldCheck size={18}/></span><span className="setting-copy"><strong>Bezpečnost a soukromí</strong><small>Buď v pohodě. Buď respektující.</small></span><ChevronRight size={18}/></button></div><div className="demo-status"><span className="demo-dot"/>{hasSupabaseConfig?'Supabase je nakonfigurovaný':'DEMO REŽIM'}<span>·</span><button onClick={()=>setToast('Tato verze ukládá data jen do tohoto prohlížeče. Pro skutečné účty nastavíme Supabase.')}>Co to znamená?</button></div></section>}
    </main>
    {!selectedChat&&<nav className="bottom-nav"><button className={activeTab==='discover'?'active':''} onClick={()=>setActiveTab('discover')}><Sparkles size={21}/><span>Objevovat</span></button><button className={activeTab==='matches'?'active':''} onClick={()=>setActiveTab('matches')}><Heart size={21}/><span>Shody{matches.length>0&&<i>{matches.length}</i>}</span></button><button className={activeTab==='profile'?'active':''} onClick={()=>setActiveTab('profile')}><UserRound size={21}/><span>Profil</span></button></nav>}
    {showJoin&&<div className="modal-backdrop" onClick={()=>setShowJoin(false)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setShowJoin(false)}><X size={20}/></button><div className="modal-icon"><ScanLine size={23}/></div><div className="eyebrow">JINÝ KLUB, JINÝ VEČER</div><h2>Připoj se k místu.</h2><p>Naskenuj QR kód u vstupu, nebo pro demo zadej klub a kód večera ručně.</p><label>Název klubu<input value={club} onChange={e=>setClub(e.target.value)} placeholder="Např. Moon Club"/></label><label>Kód večera<input value={eventCode} onChange={e=>setEventCode(e.target.value)} placeholder="Např. SAT-1010"/></label><button className="primary wide" onClick={joinClub}>Připojit se <ChevronRight size={17}/></button><div className="tiny subtle">Demo režim: název klubu a kód se ukládají jen do tohoto prohlížeče.</div></div></div>}
    {showQR&&<div className="modal-backdrop" onClick={()=>setShowQR(false)}><div className="modal qr-modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setShowQR(false)}><X size={20}/></button><div className="modal-icon"><QrCode size={23}/></div><div className="eyebrow">VSTUP DO VEČERA</div><h2>Tvůj klub. Tvůj večer.</h2><p>Tohle je odkaz, který může klub použít jako QR kód na vstupu.</p><div className="qr-placeholder"><QRCodeSVG value={qrUrl} size={130} bgColor="#f5efff" fgColor="#21182b" level="M"/><span>QR KÓD VEČERA</span></div><div className="qr-link">{qrUrl}</div><button className="primary wide" onClick={()=>{navigator.clipboard?.writeText(qrUrl);setToast('Odkaz zkopírován.');setShowQR(false)}}>Zkopírovat odkaz <ExternalLink size={16}/></button><div className="tiny subtle">Pro ostrý provoz je potřeba podepisovaný QR token ověřovaný serverem.</div></div></div>}
    {showProfileEdit&&<div className="modal-backdrop" onClick={()=>setShowProfileEdit(false)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setShowProfileEdit(false)}><X size={20}/></button><div className="eyebrow">AŤ VĚDÍ, KDO JSI</div><h2>Uprav svůj profil.</h2><p>Stačí pár detailů. Profil můžeš kdykoliv skrýt.</p><label>Jméno / přezdívka<input maxLength={24} value={profile.name} onChange={e=>setProfile(p=>({...p,name:e.target.value}))}/></label><label>Věk<input type="number" min={18} max={99} value={profile.age} onChange={e=>setProfile(p=>({...p,age:Math.max(18,Number(e.target.value))}))}/></label><label>Krátké bio<textarea maxLength={120} value={profile.bio} onChange={e=>setProfile(p=>({...p,bio:e.target.value}))}/></label><label>Zájmy <small className="subtle">(odděluj čárkou)</small><input value={profile.interests.join(', ')} onChange={e=>setProfile(p=>({...p,interests:e.target.value.split(',').map(s=>s.trim()).filter(Boolean).slice(0,5)}))}/></label><button className="secondary wide" onClick={()=>fileInput.current?.click()}><Camera size={17}/> {profile.photo?'Změnit fotku':'Přidat profilovou fotku'}</button><button className="primary wide" onClick={()=>{if(profile.name.trim().length<2){setToast('Zadej prosím přezdívku.');return}setShowProfileEdit(false);setToast('Profil uložen.') }}>Uložit profil <Check size={17}/></button></div></div>}
    {toast&&<div className="toast"><Sparkles size={16}/>{toast}</div>}
    <div className="dev-label">MVP PREVIEW · {hasSupabaseConfig?'SUPABASE CONFIGURED':'LOCAL DEMO'}</div>
  </div>
}
